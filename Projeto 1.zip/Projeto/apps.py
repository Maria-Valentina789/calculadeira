from flask import Flask, render_template, request

app = Flask(__name__)


@app.route("/", methods=["GET", "POST"])
def index():
    resultado = None
    unidade = ""
    formula = ""
    erro = None

    if request.method == "POST":
        try:
            tipo = request.form.get("tipo")

            if tipo == "tensao":
                resistencia = float(request.form["resistencia"])
                corrente = float(request.form["corrente"])

                if resistencia < 0 or corrente < 0:
                    raise ValueError

                resultado = resistencia * corrente
                unidade = "V"
                formula = f"V = {resistencia:g} × {corrente:g}"

            elif tipo == "corrente":
                tensao = float(request.form["tensao"])
                resistencia = float(request.form["resistencia"])

                if resistencia <= 0:
                    raise ValueError

                resultado = tensao / resistencia
                unidade = "A"
                formula = f"I = {tensao:g} ÷ {resistencia:g}"

            elif tipo == "resistencia":
                tensao = float(request.form["tensao"])
                corrente = float(request.form["corrente"])

                if corrente <= 0:
                    raise ValueError

                resultado = tensao / corrente
                unidade = "Ω"
                formula = f"R = {tensao:g} ÷ {corrente:g}"

            elif tipo == "potencia":
                tensao = float(request.form["tensao"])
                corrente = float(request.form["corrente"])

                resultado = tensao * corrente
                unidade = "W"
                formula = f"P = {tensao:g} × {corrente:g}"

            elif tipo == "energia":
                potencia = float(request.form["potencia"])
                horas = float(request.form["horas"])

                resultado = (potencia * horas) / 1000
                unidade = "kWh"
                formula = f"E = ({potencia:g} × {horas:g}) ÷ 1000"

            elif tipo == "custo":
                potencia = float(request.form["potencia"])
                horas = float(request.form["horas"])
                dias = float(request.form["dias"])
                tarifa = float(request.form["tarifa"])

                consumo = potencia * horas * dias / 1000
                resultado = consumo * tarifa

                unidade = "R$"
                formula = f"{consumo:.2f} kWh × R$ {tarifa:.2f}"

            else:
                raise ValueError

            resultado = f"{resultado:,.4f}"
            resultado = resultado.replace(",", "X")
            resultado = resultado.replace(".", ",")
            resultado = resultado.replace("X", ".")

        except (ValueError, KeyError, TypeError):
            erro = "Digite valores válidos."

    return render_template(
        "index.html",
        resultado=resultado,
        unidade=unidade,
        formula=formula,
        erro=erro,
    )


if __name__ == "__main__":
    app.run(debug=True)
